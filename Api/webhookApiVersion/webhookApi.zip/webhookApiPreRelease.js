const axios = require('axios');

exports.handler = async (event) => {
	//
	// Set JSON payload received from front-end to global variable

	// Global vars

	let responseWebhook;
	let sseData = {};

	const jsonPayload = event;

	console.log('Event JSON:', jsonPayload);

	const slackChannelName = jsonPayload.slackChannelName;
	const currentUserAlias = jsonPayload.currentUserAlias;
	const activeUsers = jsonPayload.activeUsers;
	const notes = jsonPayload.notes;
	const webhookUrl =
		'https://hooks.slack.com/workflows/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';
	const webhookpayload = {
		slackChannelName: slackChannelName,
		currentUserAlias: currentUserAlias,
		activeUsers: activeUsers,
		notes: notes,
		usersToInvite: 'example@example.com',
	};
	const emails = [currentUserAlias, ...activeUsers].map((user) => {
		return user.concat('@amazon.com');
	});
	sseData.emails = emails;

	console.log('User Emails:', emails);

	// ------------------------------ Send Webhook ----------------------------- //

	try {
		console.log(`
					
			Channel Name: ${slackChannelName}
			Active User Aliases: ${activeUsers}
			Current User Alias:  ${currentUserAlias}
			Slack User Emails: ${emails}
			Channel Topic:  ${notes}
			
			`);

		const headersList = {
			'Content-Type': 'application/json; charset=utf-8',
		};

		var reqOptions = {
			url: webhookUrl,
			method: 'POST',
			headers: headersList,
			data: webhookpayload,
			timeout: 20000,
		};

		var response = await axios.request(reqOptions);

		// Store response in global var

		responseWebhook = response;

		if (!responseWebhook.data.ok) {
			return {
				statusCode: 400,
				body: response.data.error,
			};
		}
	} catch (error) {
		console.error('Error responses during api calls: ', error);
		return {
			statusCode: 400,
			body: JSON.stringify(error),
		};
	}
	console.log('Response Array: ', sseData);

	let responseBody = {
		input: event,
	};

	let responseFrontEnd = {
		statusCode: 200,
		body: responseBody,
	};
	console.log('response: ' + responseFrontEnd);
	return responseFrontEnd;
};
